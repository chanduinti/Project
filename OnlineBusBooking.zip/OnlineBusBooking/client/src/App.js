import "./App.css";
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  useParams,
} from "react-router-dom";

// import './assets/vendor/jquery/jquery.min.js'

import Login from "./components/login";
import Register from "./components/register";
import Main from "./components/Main";
import Introduction from "./components/Introduction";
import SearchBus from "./components/SearchBus";
import BookedTickets from "./components/BookedTickets";
function App() {
  return (
    <Router>
      <div>
        <Main>
          <Switch>
            
              <Route path="/register">
              <Register/>
              </Route>
            <Route path="/searchbus">
              <SearchBus />
            </Route>
            <Route path="/bookedtickets">
              <BookedTickets />
            </Route>
            <Route path="/app">
              <Introduction />
            </Route>
            <Route path="/">
              <Login/>
              </Route>
          </Switch>
        </Main>
      </div>
    </Router>
  );
}

export default App;
