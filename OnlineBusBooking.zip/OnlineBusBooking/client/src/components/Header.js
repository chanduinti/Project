import React, { useState } from "react";
import { Link, useHistory } from "react-router-dom";

import Login from "./login";
import user from "../images/user.svg";
import arrow from "../images/arrow-down.svg";


export default function Header() {
  const [openDropdown, setOpenDropdown] = useState(false);

  return (
    <div className="header-box">
      
      <div className="header-user">
        <button
          className="header-user-box"
          onClick={() => setOpenDropdown(!openDropdown)}
        >
          <img src={user} alt="" className="header-user-logo" />
          <img
            src={arrow}
            alt=""
            className={
              openDropdown
                ? "header-dropdown-arrow-open"
                : "header-dropdown-arrow"
            }
          />
        </button>
        {openDropdown ? (
          <ul className="header-dropdown">
            <li>
              <Link to={"/login"}>
               <button
                className="header-dropdown-button"
                onClick={() => console.log("SignIn")}
              >
                SignIn
              </button>
              </Link>
            </li>
            <li>
              <Link to={"/register"}>
              <button
                className="header-dropdown-button"
                onClick={() => console.log("Register")}
              >
                Register
              </button>
              </Link>
            </li>
          </ul>
        ) : (
          <div></div>
        )}
      </div>
    </div>
  );
}
