import React, { Component } from 'react';
import axios from 'axios';
import {Link, Redirect} from 'react-router-dom';

export default class Register extends Component {

    state = {
        name: '',
        email: '',
        password: '',
        redirect: false,
        authError: false,
        isLoading: false,
    };

    handleEmailChange = event => {
        this.setState({ email: event.target.value });
    };
    handlePwdChange = event => {
        this.setState({ password: event.target.value });
    };
    handleNameChange = event => {
        this.setState({ name: event.target.value });
    };

    handleSubmit = event => {
        event.preventDefault();
        this.setState({isLoading: true});
        const url = 'https://gowtham-rest-api-crud.herokuapp.com/register';
        const email = this.state.email;
        const password = this.state.password;
        const name = this.state.name;
        let bodyFormData = new FormData();
        bodyFormData.set('email', email);
        bodyFormData.set('name', name);
        bodyFormData.set('password', password);
        axios.post(url, bodyFormData)
            .then(result => {
                this.setState({isLoading: false});
                if (result.data.status !== 'fail') {
                    this.setState({redirect: true, authError: true});
                }else {
                    this.setState({redirect: false, authError: true});
                }
            })
            .catch(error => {
                console.log(error);
                this.setState({ authError: true, isLoading: false });
            });
    };

    renderRedirect = () => {
        if (this.state.redirect) {
            return <Redirect to="/" />
        }
    };

    render() {
        const isLoading = this.state.isLoading;
        return (
            <div className="container">
                <div className="card card-login mx-auto mt-5">
                    <div className="card-header">Register</div>
                    <div className="card-body">
                        <form onSubmit={this.handleSubmit}>
                            <div className="form-group">
                                <div className="form-label-group">
                                    <input type="text" id="inputName" className="form-control" placeholder="name"  name="name" onChange={this.handleNameChange} required/>
                                    <label htmlFor="inputName">Name</label>
                                </div>
                            </div>

                            <div className="form-group">
                                <div className="form-label-group">
                                    <input id="inputEmail" className={"form-control " + (this.state.authError ? 'is-invalid' : '')} placeholder="Email address" type="text" name="email" onChange={this.handleEmailChange} autoFocus required/>
                                    <label htmlFor="inputEmail">Email address</label>
                                    <div className="invalid-feedback">
                                        Please provide a valid Email. or Email Exis
                                    </div>
                                </div>
                            </div>
                            <div className="form-group">
                                <div className="form-label-group">
                                    <input type="password" className="form-control" id="inputPassword" placeholder="******"  name="password" onChange={this.handlePwdChange} required/>
                                    <label htmlFor="inputPassword">Password</label>
                                </div>
                            </div>

                            <div className="form-group">
                                <button className="btn btn-primary btn-block" type="submit" disabled={this.state.isLoading ? true : false}>Register &nbsp;&nbsp;&nbsp;
                                    {isLoading ? (
                                        <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                    ) : (
                                        <span></span>
                                    )}
                                </button>
                            </div>
                        </form>
                        <div className="text-center">
                            <Link className="d-block small mt-3" to={''}>Login Your Account</Link>
                            <Link className="d-block small" to={'#'}>Forgot Password?</Link>
                        </div>
                    </div>
                </div>
                {this.renderRedirect()}
            </div>
        );
    }
}

// import React, {Component} from "react";
// import { useFormik } from 'formik'
// import * as yup from 'yup';
// import axios from 'axios'
// import { toast } from 'react-toastify';
// import { useNavigate } from "react-router-dom";
// import Register from "./components/register";


// const Register = (props) => {
//     let navigate = useNavigate();
//     const formik = useFormik({
//         initialValues: {
//             name: '',
//             email: '',
//             password: '',
//             confirmpassword: ''
//         },
//         validationSchema: yup.object({
//             name: yup.string()
//             .strict()
//             .trim()
//             .required('Name is required'),
//             email: yup.string()
//             .email('Enter valid email address')
//             .strict()
//             .trim()
//             .required('EmailID is required'),
//             password: yup.string()           
//             .strict()
//             .trim()
//             .required('please enter password'),
//             confirmpassword: yup.string()           
//             .oneOf([yup.ref('password'), null], 'must be same as password')
//             .required('please enter confirm password'),
//         }),
//         onSubmit: (data) => {
//             console.log(data);
//             axios.post('http://localhost:5000/api/register', data)
//             .then(res => {           
//                 toast.success("user registered successfully");    
//                 navigate("/login", { replace: true});
//             })
//             .catch(err => {
//                 toast.error(err.response.data);
//             })            
//         }
//      });
// return (
//        <div className="container mt-4">
//            <div>
//                <h4>Regiser</h4>
//                <form autoComplete="off" onSubmit={formik.handleSubmit}>
//                    <div className="form-group">
//                        <label>Name</label>
//                        <input name="name" className="form-control" type="text" onChange={formik.handleChange} value={formik.values.name} />
//                        {formik.errors.name ? 
//                           <div className="text-danger">{formik.errors.name}</div>
//                           : null
//                        }
//                    </div>
//                    <div className="form-group">
//                        <label>Email</label>
//                        <input name="email" className="form-control" type="text" onChange={formik.handleChange} value={formik.values.email} />
//                        {formik.errors.email ? 
//                           <div className="text-danger">{formik.errors.email}</div>
//                           : null
//                        }
//                    </div>
//                    <div className="form-group">
//                        <label>Password</label>
//                        <input name="password" className="form-control" type="text" onChange={formik.handleChange} value={formik.values.password} />
//                        {formik.errors.password ? 
//                           <div className="text-danger">{formik.errors.password}</div>
//                           : null
//                        }
//                    </div>
//                    <div className="form-group">
//                        <label>Confirm Password</label>
//                        <input name="confirmpassword" className="form-control" type="text" onChange={formik.handleChange} value={formik.values.confirmpassword} />
//                        {formik.errors.confirmpassword ? 
//                           <div className="text-danger">{formik.errors.confirmpassword}</div>
//                           : null
//                        }
//                    </div>
//                    <div className="d-flex justify-content-between"></div>
//                    <button className="btn btn-primary" type="submit">Submit</button>
//                    <a 
//                         href="#" onClick={() => {
//                        window.location.href='login'; 
//                         }}
//                     >
//                        Login</a>
                   
//                </form>
//            </div>
//        </div>
//     )
// }

// export default Register;

