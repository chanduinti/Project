import React from "react";
import logo from "../images/bus-side-view-grey.svg";
import github from "../images/github.svg";
import twitter from "../images/twitter.svg";
import moment from "moment";

export default function Footer() {
  return (
    <div className="footer">
     
    </div>
  );
}
