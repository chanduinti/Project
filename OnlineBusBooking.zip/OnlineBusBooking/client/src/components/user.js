const router = require('express').Router();
const User = require('./userSchema');
const bcrypt = require('bcrypt');

router.post('/register',async (req,res) => {
   
    try {
        var emailExist = await User.findOne({email:req.body.email});
        if(emailExist) {
            return res.status(400).json("Email already exist");
        }
        var hash = await bcrypt.hash(req.body.password, 6);

        const user = new User({
            name:req.body.name,
            email:req.body.email,
            password:hash,
        });

        var data = await user.save();
        res.json(data);
    }
   
    catch(err) {
        res.status(400).json(err);
    }
    res.json(User)
});

module.exports = router;