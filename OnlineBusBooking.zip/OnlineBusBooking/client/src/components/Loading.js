import React from "react";

export default function Loading({ title }) {
  return (
    <div className="loading">
      <div className="loading-title-box">
        <span className="loading-title">{title ? title : "Loading"}</span>
        
      </div>
    </div>
  );
}
