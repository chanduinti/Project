var express = require("express");
var router = express.Router();
const Bus = require("../models/Bus");
var moment = require("moment");
const CitiesData = require("./cities.json");

/* GET buses listing. */
router.get("/", function (req, res, next) {
  res.send("respond with a resource");
});

router.get("/saveAllBuses", function (req, res, next) {
  function generateRandomBusData() {
    let city = JSON.parse(JSON.stringify(CitiesData));

    let cities = city.map((each) => each.city);

    let busesName = [
      "Parveen Travels",
      "Chandu Travels",
      "Orange Travels",
      "Deepthi Travels",
      "ISN Travels",
    ];

    let boardingPoint = [
      {
        add_time: 15,
        placename: "CPM OFFICE NEAR, OMAGA HOSPITAL",
        address: "NH4 HIGHWAY Parking Road, SIVA APAERTMENT Square, near Omaga Hospital",
      },
      {
        add_time: 30,
        placename: "ALLU OFFICE ",
        address: "ALLU OFFICE, near Kalavathi Builiding , GURT Road",
      },
      {
        add_time: 45,
        placename: "Nehuru Hospital near City Bus Stand",
        address: "Near City Bus Stand-Nehuru Hospital",
      },
    ];

    let droppingPoint = [
      {
        remove_time: 30,
        placename: "Nehuru Hospital",
        address: "Nehuru Hospital",
      },
      {
        remove_time: 15,
        placename: "Near Laxmi Nagar",
        address: "Near Laxmi Nagar",
      },
      {
        remove_time: 0,
        placename: "Shivaji Gate Office",
        address: "Shivaji Gate",
      },
    ];

    function getRandomPrice(max, min) {
      return Math.floor(Math.random() * (max - min) + min);
    }

    function getRandomTrue() {
      let value = Math.floor(Math.random() * 2);
      if (value) {
        return true;
      } else {
        return false;
      }
    }

    function getBusData() {
      let data = [];
      for (let cityFrom of cities) {
        for (let cityTo of cities) {
          let boardingPointData = boardingPoint.map((each) => {
            let value = {
              add_time: each.add_time,
              placename: each.placename,
              address: each.address + ", " + cityFrom,
            };
            return value;
          });

          let droppingPointData = droppingPoint.map((each) => {
            let value = {
              remove_time: each.remove_time,
              placename: each.placename,
              address: each.address + ", " + cityTo,
            };
            return value;
          });
          for (let travelName of busesName) {
            if (getRandomTrue() && cityFrom !== cityTo) {
              let value = {
                name: travelName,
                to: cityTo,
                from: cityFrom,
                ac: getRandomTrue(),
                type: "Sleeper(2T)",
                timing: {
                  departure: moment().toISOString(),
                  arrival: moment()
                    .add(getRandomPrice(12, 7), "h")
                    .toISOString(),
                },

                boarding_point: [
                  {
                     add_time: 15,
                     placename: "CPM OFFICE NEAR, OMAGA HOSPITAL",
                     address: "NH4 HIGHWAY Parking Road, SIVA APAERTMENT Square, near Omaga Hospital",
                  },
                  {
                    add_time: 30,
                    placename: "ALLU OFFICE ",
                    address: "ALLU OFFICE, near Kalavathi Builiding , GURT Road",
                  },
                  {
                    add_time: 45,
                    placename: "Nehuru Hospital near City Bus Stand",
                    address: "Near City Bus Stand-Nehuru Hospital",
                  },
                ],
                dropping_point: [
                  {
                    remove_time: 30,
                    placename: "Nehuru Hospital",
                    address: "Nehuru Hospital",
                  },
                  {
                    remove_time: 15,
                    placename: "Near Laxmi Nagar",
                    address: "Near Laxmi Nagar",
                  },
                  {
                    remove_time: 0,
                    placename: "Shivaji Gate Office",
                    address: "Shivaji Gate",
                  },
                ],
                single_seat_price: getRandomPrice(1001, 950),
                share_seat_price: getRandomPrice(850, 750),
                booked_seat: [],
              };
              if (getRandomTrue()) {
                data.push(value);
              }
            }
          }
        }
      }

      return data;
    }

    // console.log(getBusData());
    return getBusData();
  }

  const data = generateRandomBusData();
  console.log(data[0]);
  let response = Bus.insertMany(data.slice(0, 10001), {
    limit: null,
    lean: true,
    ordered: false,
  });

  res.send("Saved");
});

router.get("/search", async function (req, res, next) {
  console.log(req.query.to);
  console.log(req.query.from);

  try {
    const busData = await Bus.find({ to: req.query.to, from: req.query.from });
    if (busData) {
      res.send(busData);
    }
  } catch (error) {
    throw new Error(error);
  }
});

router.post("/saveBus", async function (req, res, next) {
  var {
    name,
    to,
    from,
    ac,
    type,
    boarding_point,
    dropping_point,
    single_seat_price,
    share_seat_price,
    booked_seat,
    amenities,
  } = req.body.data;
  try {
    const newSaveBus = new Bus({
      name,
      to,
      from,
      ac,
      type,
      timing: {
        departure: moment().toISOString(),
        arrival: moment().add(8, "h").toISOString(),
      },

      boarding_point,
      dropping_point,
      single_seat_price,
      share_seat_price,
      booked_seat,
      amenities,
    });

    const savedBus = await newSaveBus.save();
    console.log(savedBus);
    res.send(savedBus);
  } catch (error) {
    throw new Error(error);
  }

  res.send(req.body);
});

router.post("/bookticket", async function (req, res, next) {
  try {
    const busData = await Bus.find({ _id: req.body.id });

    if (busData != []) {
      const bookedData = await Bus.findByIdAndUpdate(
        { _id: req.body.id },
        { $push: { booked_seat: req.body.data } },
        { new: true, lean: true }
      );

      res.send(bookedData.booked_seat[bookedData.booked_seat.length - 1]);
    }
  } catch (error) {
    throw new Error(error);
  }
});

module.exports = router;
